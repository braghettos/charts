{{/*
Common labels applied to the ACK GlobalNetwork resource.
*/}}
{{- define "aws-networkmanager-globalnetwork.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: krateo-aws-blueprint
krateo.io/composition: {{ .Release.Name }}
{{- end -}}
