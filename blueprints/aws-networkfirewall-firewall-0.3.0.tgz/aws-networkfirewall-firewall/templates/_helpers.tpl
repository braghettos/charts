{{/*
Common labels applied to the ACK Firewall resource.
*/}}
{{- define "aws-networkfirewall-firewall.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: krateo-aws-blueprint
krateo.io/composition: {{ .Release.Name }}
{{- end -}}
